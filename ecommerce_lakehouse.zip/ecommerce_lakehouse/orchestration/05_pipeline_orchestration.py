# Databricks notebook source
# ============================================================
# 05_pipeline_orchestration
# Runs Bronze → Silver Cleaning → Silver Dim/Fact → Gold KPIs
# ============================================================

import time
from datetime import datetime

# If notebooks are in SAME folder:
BASE_PATH = "/Workspace/Users/lalit.jindal@celebaltech.com/ecommerce_lakehouse"


# ============================================================
# Notebook Names (MATCH YOUR IMAGE EXACTLY)
# ============================================================

BRONZE_NOTEBOOK   = BASE_PATH + "/bronze/"+"01_bronze_ingestion"
SILVER_NOTEBOOK   = BASE_PATH + "/silver/"+"02_silver_cleaning"
DIM_FACT_NOTEBOOK = BASE_PATH +"/silver/" +"03_silver_dim_fact"
GOLD_NOTEBOOK     = BASE_PATH +"gold" +"04_gold_kpis"

TIMEOUT = 600  # seconds

# ============================================================
# Helper Function
# ============================================================

def run_step(step_name, notebook_path):
    print("\n====================================================")
    print(f"🚀 Starting: {step_name}")
    print(f"⏱ Start Time: {datetime.now()}")
    start_time = time.time()

    try:
        dbutils.notebook.run(notebook_path, TIMEOUT)

        end_time = time.time()

        print(f"✅ {step_name} SUCCESS")
        print(f"⏱ End Time: {datetime.now()}")
        print(f"⌛ Duration: {round(end_time - start_time, 2)} seconds")
        print("====================================================")

    except Exception as e:
        end_time = time.time()

        print(f"❌ {step_name} FAILED")
        print(f"⏱ End Time: {datetime.now()}")
        print(f"⌛ Duration: {round(end_time - start_time, 2)} seconds")
        print(f"🔥 Error: {str(e)}")
        print("====================================================")

        raise  # Stop pipeline immediately


# ============================================================
# 🚀 PIPELINE START
# ============================================================

pipeline_start = time.time()

print("########################################################")
print("🚀 FULL LAKEHOUSE PIPELINE STARTED")
print(f"Start Time: {datetime.now()}")
print("########################################################")

try:

    # 1️⃣ Bronze
    run_step("Bronze Ingestion", BRONZE_NOTEBOOK)

    # 2️⃣ Silver Cleaning
    run_step("Silver Cleaning", SILVER_NOTEBOOK)

    # 3️⃣ Silver Dim & Fact Creation
    run_step("Silver Dim & Fact", DIM_FACT_NOTEBOOK)

    # 4️⃣ Gold KPI Creation
    run_step("Gold KPIs", GOLD_NOTEBOOK)

    print("\n🎉 ALL STEPS COMPLETED SUCCESSFULLY")

except Exception as e:
    print("\n🛑 PIPELINE STOPPED DUE TO FAILURE")
    raise


# ============================================================
# 📊 FINAL SUMMARY
# ============================================================

pipeline_end = time.time()

print("\n########################################################")
print("📊 FINAL PIPELINE SUMMARY")
print("########################################################")

bronze_tables = [
    "ecommerce_lakehouse.bronze.raw_customers",
    "ecommerce_lakehouse.bronze.raw_orders",
    "ecommerce_lakehouse.bronze.raw_products",
    "ecommerce_lakehouse.bronze.raw_order_items"
]

silver_tables = [
    "ecommerce_lakehouse.silver.sl_customers",
    "ecommerce_lakehouse.silver.sl_orders",
    "ecommerce_lakehouse.silver.sl_products",
    "ecommerce_lakehouse.silver.sl_order_items",
    "ecommerce_lakehouse.silver.dim_customers",
    "ecommerce_lakehouse.silver.fact_orders",
    "ecommerce_lakehouse.silver.dim_products",
    "ecommerce_lakehouse.silver.fact_order_items"
]

gold_tables = [
    "ecommerce_lakehouse.gold.kpi_daily_sales_summary",
    "ecommerce_lakehouse.gold.kpi_monthly_revenue",
    "ecommerce_lakehouse.gold.kpi_customer_lifetime_value",
    "ecommerce_lakehouse.gold.kpi_product_performance",
    "ecommerce_lakehouse.gold.kpi_category_analysis",
    "ecommerce_lakehouse.gold.kpi_customer_segmentation",
    "ecommerce_lakehouse.gold.kpi_payment_method_analysis",
    "ecommerce_lakehouse.gold.kpi_executive_dashboard"
]

def print_counts(layer_name, tables):
    print(f"\n🔹 {layer_name} Layer Row Counts:")
    for t in tables:
        try:
            print(f"{t} → {spark.table(t).count()} rows")
        except:
            print(f"{t} → Not Found")

print_counts("Bronze", bronze_tables)
print_counts("Silver", silver_tables)
print_counts("Gold", gold_tables)

print("\n########################################################")
print(f"⏱ TOTAL PIPELINE TIME: {round(pipeline_end - pipeline_start, 2)} seconds")
print("########################################################")

dbutils.notebook.exit("SUCCESS")

# COMMAND ----------

