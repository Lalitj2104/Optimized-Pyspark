# Databricks notebook source
from pyspark.sql import functions as F

orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")

kpi1 = (
    orders.groupBy("order_date")
    .agg(
        F.sum("total_amount").alias("total_revenue"),
        F.count("order_id").alias("total_orders"),
        F.countDistinct("customer_id").alias("unique_customers"),
        F.round(F.avg("total_amount"), 2).alias("avg_order_value"),
        F.max("total_amount").alias("max_order_value"),
        F.min("total_amount").alias("min_order_value")
    )
    .withColumn("revenue_per_customer",
        F.col("total_revenue") / F.col("unique_customers"))
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

kpi1.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_daily_sales_summary")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")

monthly = (
    orders.withColumn("order_month",
                      F.date_format("order_date","yyyy-MM"))
    .withColumn("order_year", F.year("order_date"))
    .withColumn("order_quarter", F.quarter("order_date"))
    .groupBy("order_month","order_year","order_quarter")
    .agg(
        F.sum("total_amount").alias("monthly_revenue"),
        F.count("order_id").alias("monthly_orders"),
        F.countDistinct("customer_id").alias("monthly_active_customers"),
        F.avg("total_amount").alias("monthly_aov")
    )
)

w = Window.orderBy("order_month")

kpi2 = (monthly
    .withColumn("prev_month_revenue",
                F.lag("monthly_revenue").over(w))
    .withColumn("mom_growth_pct",
        ((F.col("monthly_revenue") - F.col("prev_month_revenue"))
         / F.col("prev_month_revenue")) * 100)
    .withColumn("cumulative_revenue",
        F.sum("monthly_revenue").over(w))
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

kpi2.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_monthly_revenue")

# COMMAND ----------

from pyspark.sql import functions as F

orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")

customers = spark.table("ecommerce_lakehouse.silver.dim_customers")

clv = (
    orders.groupBy("customer_id")
    .agg(
        F.sum("total_amount").alias("total_spend"),
        F.count("order_id").alias("total_orders"),
        F.avg("total_amount").alias("avg_order_value"),
        F.min("order_date").alias("first_order_date"),
        F.max("order_date").alias("last_order_date")
    )
    .withColumn("customer_tenure_days",
        F.datediff("last_order_date","first_order_date"))
    .withColumn("order_frequency",
        F.when(F.col("customer_tenure_days") > 0,
               F.col("total_orders") / (F.col("customer_tenure_days")/30))
         .otherwise(F.col("total_orders")))
    .withColumn("projected_clv_12m",
        F.col("avg_order_value") *
        F.col("order_frequency") * 12)
)

kpi3 = (clv.join(customers, "customer_id")
    .select(
        "customer_id",
        "first_name",
        "last_name",
        "email",
        "city",
        "state",
        "total_spend",
        "total_orders",
        "avg_order_value",
        "first_order_date",
        "last_order_date",
        "customer_tenure_days",
        "order_frequency",
        "projected_clv_12m"
    )
    .withColumn("clv_tier",
        F.when(F.col("projected_clv_12m") >= 500, "Platinum")
         .when(F.col("projected_clv_12m") >= 300, "Gold")
         .when(F.col("projected_clv_12m") >= 150, "Silver")
         .otherwise("Bronze"))
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

kpi3.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_customer_lifetime_value")

# COMMAND ----------

spark.table("ecommerce_lakehouse.silver.fact_order_items").printSchema()

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# Read tables
items = spark.table("ecommerce_lakehouse.silver.fact_order_items")
orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")
products = spark.table("ecommerce_lakehouse.silver.dim_products")

# Cast numeric columns properly
items = (
    items
    .withColumn("quantity", F.col("quantity").cast("double"))
    .withColumn("unit_price", F.col("unit_price").cast("double"))
    .withColumn("line_total", F.col("line_total").cast("double"))
    .withColumn("discount_pct",
        F.when(F.col("discount_pct").isNull(), 0.0)
         .otherwise(F.col("discount_pct")))
)

# Join with completed orders and product dimension
joined = (
    items.join(orders.select("order_id"), "order_id", "inner")
         .join(products.select(
                "product_id",
                "product_name",
                "category",
                "sub_category",
                "cost_price"
         ), "product_id", "inner")
)

# Calculate discount amount safely
joined = joined.withColumn(
    "discount_amount",
    F.round(
        F.col("quantity") *
        F.col("unit_price") *
        (F.col("discount_pct") / 100),
        2
    )
)

# Aggregate
kpi4 = (
    joined.groupBy(
        "product_id",
        "product_name",
        "category",
        "sub_category",
        "cost_price"
    )
    .agg(
        F.sum("quantity").alias("total_units_sold"),
        F.sum("line_total").alias("total_revenue"),
        F.sum("discount_amount").alias("total_discounts_given"),
        F.count("item_id").alias("times_ordered")
    )
)

# Derived metrics
kpi4 = (
    kpi4
    .withColumn("total_cost",
        F.col("total_units_sold") * F.col("cost_price"))
    .withColumn("gross_profit",
        F.col("total_revenue") - F.col("total_cost"))
    .withColumn("gross_margin_pct",
        F.when(F.col("total_revenue") != 0,
               (F.col("gross_profit") / F.col("total_revenue")) * 100)
         .otherwise(0))
)

# Ranking (global — as required)
revenue_window = Window.orderBy(F.col("total_revenue").desc())
units_window = Window.orderBy(F.col("total_units_sold").desc())

kpi4 = (
    kpi4
    .withColumn("revenue_rank",
        F.dense_rank().over(revenue_window))
    .withColumn("units_rank",
        F.dense_rank().over(units_window))
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

# Write to Gold
kpi4.write.mode("overwrite") \
    .format("delta") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_product_performance")

print("✅ KPI 4 created successfully")

# COMMAND ----------

from pyspark.sql import functions as F

items = spark.table("ecommerce_lakehouse.silver.fact_order_items")
orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")
products = spark.table("ecommerce_lakehouse.silver.dim_products")

# Cast numeric fields
items = (
    items
    .withColumn("quantity", F.col("quantity").cast("double"))
    .withColumn("line_total", F.col("line_total").cast("double"))
)

# Join tables
joined = (
    items.join(orders.select("order_id"), "order_id")
         .join(products.select(
                "product_id",
                "category",
                "sub_category",
                "cost_price"
         ), "product_id")
)

# Calculate row-level cost first
joined = joined.withColumn(
    "row_cost",
    F.col("quantity") * F.col("cost_price")
)

# Now aggregate correctly
kpi5 = (
    joined.groupBy("category", "sub_category")
    .agg(
        F.sum("quantity").alias("total_units_sold"),
        F.sum("line_total").alias("total_revenue"),
        F.countDistinct("order_id").alias("unique_orders"),
        F.sum("row_cost").alias("total_cost")
    )
)

# Derived metrics
total_company_revenue = kpi5.agg(F.sum("total_revenue")).first()[0]

kpi5 = (
    kpi5
    .withColumn("gross_profit",
        F.col("total_revenue") - F.col("total_cost"))
    .withColumn("gross_margin_pct",
        F.when(F.col("total_revenue") != 0,
               (F.col("gross_profit") / F.col("total_revenue")) * 100)
         .otherwise(0))
    .withColumn("category_revenue_share_pct",
        (F.col("total_revenue") / F.lit(total_company_revenue)) * 100)
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

kpi5.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_category_analysis")

print("✅ KPI 5 fixed and created successfully")

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")

# Aggregate RFM metrics
rfm = (
    orders.groupBy("customer_id")
    .agg(
        F.datediff(F.current_date(),
                   F.max("order_date")).alias("recency"),
        F.count("order_id").alias("frequency"),
        F.sum("total_amount").alias("monetary")
    )
)

# Apply NTILE scoring
rfm = (
    rfm
    .withColumn("r_score", F.ntile(4).over(Window.orderBy("recency")))
    .withColumn("f_score", F.ntile(4).over(Window.orderBy("frequency")))
    .withColumn("m_score", F.ntile(4).over(Window.orderBy("monetary")))
    .withColumn("rfm_score",
        F.col("r_score") + F.col("f_score") + F.col("m_score"))
    .withColumn("segment",
        F.when(F.col("rfm_score") >= 10, "Champions")
         .when(F.col("rfm_score") >= 8, "Loyal Customers")
         .when(F.col("rfm_score") >= 6, "Potential Loyalists")
         .when(F.col("rfm_score") >= 4, "At Risk")
         .otherwise("Needs Attention"))
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

rfm.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_customer_segmentation")

print("✅ KPI 6 created")

# COMMAND ----------

from pyspark.sql import functions as F

orders = spark.table("ecommerce_lakehouse.silver.fact_orders") \
              .filter(F.col("order_status") == "COMPLETED")

kpi7 = (
    orders.groupBy("payment_method")
    .agg(
        F.sum("total_amount").alias("total_revenue"),
        F.count("order_id").alias("order_count"),
        F.countDistinct("customer_id").alias("unique_customers"),
        F.avg("total_amount").alias("avg_order_value")
    )
)

total_revenue = kpi7.agg(F.sum("total_revenue")).first()[0]

kpi7 = (
    kpi7
    .withColumn("revenue_share_pct",
        (F.col("total_revenue") / F.lit(total_revenue)) * 100)
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

kpi7.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_payment_method_analysis")

print("✅ KPI 7 created")

# COMMAND ----------

from pyspark.sql import functions as F

orders = spark.table("ecommerce_lakehouse.silver.fact_orders")
items = spark.table("ecommerce_lakehouse.silver.fact_order_items")
customers = spark.table("ecommerce_lakehouse.silver.dim_customers")
products = spark.table("ecommerce_lakehouse.silver.dim_products")

completed = orders.filter(F.col("order_status") == "COMPLETED")

# Cast numeric columns in items
items = (
    items
    .withColumn("quantity", F.col("quantity").cast("double"))
    .withColumn("unit_price", F.col("unit_price").cast("double"))
    .withColumn("discount_pct",
        F.when(F.col("discount_pct").isNull(), 0)
         .otherwise(F.col("discount_pct")))
)

# Compute totals safely
total_units = items.agg(F.sum("quantity")).first()[0]

total_discounts = (
    items.withColumn("discount_amount",
        F.col("quantity") *
        F.col("unit_price") *
        (F.col("discount_pct")/100))
    .agg(F.sum("discount_amount"))
    .first()[0]
)

returned_orders = orders.filter(
    F.col("order_status").isin("RETURNED","REFUNDED")
).count()

total_orders_all = orders.count()

exec_kpi = completed.agg(
    F.sum("total_amount").alias("total_revenue"),
    F.count("order_id").alias("total_orders"),
    F.countDistinct("customer_id").alias("active_customers"),
    F.avg("total_amount").alias("avg_order_value")
)

exec_kpi = (
    exec_kpi
    .withColumn("total_customers",
        F.lit(customers.count()))
    .withColumn("customer_activation_rate",
        (F.col("active_customers") /
         F.col("total_customers")) * 100)
    .withColumn("total_units_sold",
        F.lit(total_units))
    .withColumn("total_discounts_given",
        F.lit(total_discounts))
    .withColumn("return_rate_pct",
        F.lit((returned_orders / total_orders_all) * 100))
    .withColumn("active_products",
        F.lit(products.filter(F.col("is_active")==True).count()))
    .withColumn("report_date", F.current_date())
    .withColumn("_gold_loaded_at", F.current_timestamp())
)

exec_kpi.write.mode("overwrite") \
    .saveAsTable("ecommerce_lakehouse.gold.kpi_executive_dashboard")

print("✅ KPI 8 created")

# COMMAND ----------

