# Databricks notebook source
# MAGIC %md
# MAGIC ### Configuring imports

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, input_file_name, lit, max as spark_max
import uuid
import time

# COMMAND ----------

# MAGIC %md
# MAGIC ###Fetching the bronze layer metadata

# COMMAND ----------

bronze_meta_df=spark.sql(''' Select * from ecommerce_lakehouse.config.metadata where layer='bronze' and isactive = true ''')

# COMMAND ----------

bronze_meta_df.display()

# COMMAND ----------

configs=bronze_meta_df.collect()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit, col, max as spark_max
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, DoubleType, LongType
import uuid
import time

# =====================================================
# READ ACTIVE METADATA
# =====================================================

metadata_df = spark.table("ecommerce_lakehouse.config.metadata") \
                   .filter("isactive = true AND layer = 'bronze'")

configs = metadata_df.collect()

pipeline_run_id = str(uuid.uuid4())
pipeline_start_time = time.time()

print(f"Pipeline Run ID: {pipeline_run_id}")

# =====================================================
# LOOP
# =====================================================

for row in configs:

    meta_id = row.meta_id
    source_path = f"{row.source_path}{row.source_folder}/"
    target_table = f"{row.target_path}.{row.target_table}"
    watermark_column = row.watermark_column

    table_start_time = time.time()
    start_ts = spark.sql("select current_timestamp()").first()[0]

    checkpoint_path = f"/Volumes/ecommerce_lakehouse/default/checkpoints/{row.source_folder}/"
    schema_path = f"/Volumes/ecommerce_lakehouse/default/schema/{row.source_folder}/"

    print(f"\nProcessing: {meta_id} → {target_table}")

    try:

        # =====================================================
        # AUTO LOADER
        # =====================================================

        (
            spark.readStream
                .format("cloudFiles")
                .option("cloudFiles.format", "csv")  # change if needed
                .option("header", "true")
                .option("cloudFiles.schemaLocation", schema_path)
                .load(source_path)
                .withColumn("ingestion_time", current_timestamp())
                .withColumn("meta_id", lit(meta_id))
                .writeStream
                .format("delta")
                .option("checkpointLocation", checkpoint_path)
                .option("mergeSchema", "true")
                .trigger(availableNow=True)
                .toTable(target_table)
        )

        # =====================================================
        # COUNT ONLY NEWLY INSERTED ROWS
        # =====================================================

        inserted_count = (
            spark.table(target_table)
                 .filter(
                     (col("ingestion_time") >= start_ts) &
                     (col("meta_id") == meta_id)
                 )
                 .count()
        )

        source_count = inserted_count

        # =====================================================
        # WATERMARK UPDATE (SAFE)
        # =====================================================

        if watermark_column and watermark_column in spark.table(target_table).columns:

            max_value = (
                spark.table(target_table)
                     .filter(col("meta_id") == meta_id)
                     .agg(spark_max(watermark_column))
                     .first()[0]
            )

            if max_value:
                spark.sql(f"""
                    UPDATE ecommerce_lakehouse.config.metadata
                    SET max_updated_date = TIMESTAMP('{max_value}'),
                        updated_date = current_timestamp()
                    WHERE meta_id = '{meta_id}'
                """)

        status = "SUCCESS"
        description = "Ingestion completed successfully"

    except Exception as e:
        inserted_count = 0
        source_count = 0
        status = "FAILED"
        description = str(e)

    end_ts = spark.sql("select current_timestamp()").first()[0]
    duration = float(time.time() - table_start_time)

    # =====================================================
    # AUDIT INSERT
    # =====================================================

    audit_schema = StructType([
        StructField("meta_id", StringType(), True),
        StructField("run_id", StringType(), True),
        StructField("run_date", TimestampType(), True),
        StructField("layer", StringType(), True),
        StructField("source_file", StringType(), True),
        StructField("target_file", StringType(), True),
        StructField("source_table", StringType(), True),
        StructField("target_table", StringType(), True),
        StructField("start_time", TimestampType(), True),
        StructField("end_time", TimestampType(), True),
        StructField("duration", DoubleType(), True),
        StructField("source_count", LongType(), True),
        StructField("inserted_count", LongType(), True),
        StructField("status", StringType(), True),
        StructField("description", StringType(), True)
    ])

    table_run_id = str(uuid.uuid4())

    audit_data = [(
        meta_id,
        pipeline_run_id,
        start_ts,
        "bronze",
        source_path,
        target_table,
        row.source_folder,
        row.target_table,
        start_ts,
        end_ts,
        duration,
        int(source_count),
        int(inserted_count),
        status,
        description
    )]

    spark.createDataFrame(audit_data, schema=audit_schema) \
         .write \
         .mode("append") \
         .saveAsTable("ecommerce_lakehouse.config.audit_logging")

    print(f"Completed: {meta_id} | Inserted: {inserted_count}")

pipeline_duration = time.time() - pipeline_start_time
print(f"\nPipeline Completed in {pipeline_duration} seconds")

# COMMAND ----------

spark.sql('''select * from ecommerce_lakehouse.bronze.br_products''').display()

# COMMAND ----------

spark.sql('''select * from ecommerce_lakehouse.bronze.br_products''').display()

# COMMAND ----------

