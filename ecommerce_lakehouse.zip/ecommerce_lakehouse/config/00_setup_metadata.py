# Databricks notebook source
# MAGIC %md
# MAGIC ###Imports
# MAGIC

# COMMAND ----------

# DBTITLE 1,Cell 2
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ##Creating metadata table

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE table if not EXISTS ecommerce_lakehouse.config.metadata(
# MAGIC   meta_id STRING,
# MAGIC   source_folder STRING,
# MAGIC   source_path STRING,
# MAGIC   source_table STRING,
# MAGIC   target_folder STRING,
# MAGIC   target_path STRING,
# MAGIC   target_table STRING,
# MAGIC   load_type STRING,
# MAGIC   layer STRING,
# MAGIC   isactive BOOLEAN,
# MAGIC   notebook_or_pipeline_name string,
# MAGIC   trigger_time STRING,
# MAGIC   primary_key string,
# MAGIC   watermark_column string,
# MAGIC   inserted_date TIMESTAMP,
# MAGIC   updated_date TIMESTAMP,
# MAGIC   max_updated_date TIMESTAMP
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Inserting for raw-input to raw-output

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO ecommerce_lakehouse.config.metadata VALUES
# MAGIC
# MAGIC -- Customers
# MAGIC ('IOCUS001','customers',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-input/',null,
# MAGIC  'customers',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-output/',null,
# MAGIC  'incremental','input_to_output',true,'pl_ingest_dynamic',
# MAGIC  null,null,NULL,current_date(),current_timestamp(),NULL),
# MAGIC
# MAGIC -- Orders
# MAGIC ('IOORD001','orders',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-input/',null,
# MAGIC  'orders',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-output/',null,
# MAGIC  'incremental','input_to_output',true,'pl_ingest_dynamic',
# MAGIC  null,null,NULL,current_date(),current_timestamp(),NULL),
# MAGIC
# MAGIC -- Products
# MAGIC ('IOPRD001','products',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-input/',null,
# MAGIC  'products',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-output/',null,
# MAGIC  'incremental','input_to_output',true,'pl_ingest_dynamic',
# MAGIC  null,null,NULL,current_date(),current_timestamp(),NULL),
# MAGIC
# MAGIC -- Order Items
# MAGIC ('IOOIT001','order_items',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-input/',null,
# MAGIC  'order_items',
# MAGIC  'abfss://ecommerce-lakehouse@sasidratraining001.dfs.core.windows.net/raw-output/',null,
# MAGIC  'incremental','input_to_output',true,'pl_ingest_dynamic',
# MAGIC  null,null,NULL,current_date(),current_timestamp(),NULL);
# MAGIC

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from ecommerce_lakehouse.config.metadata

# COMMAND ----------

# MAGIC %md
# MAGIC ### Inserting metadata for input-output to bronze

# COMMAND ----------

# MAGIC %sql
# MAGIC -- LAYER: OUTPUT → BRONZE
# MAGIC INSERT INTO ecommerce_lakehouse.config.metadata VALUES
# MAGIC -- Customers
# MAGIC ('OBCUS001','customers','/Volumes/ecommerce_lakehouse/default/raw/',NULL,
# MAGIC NULL,'ecommerce_lakehouse.bronze','br_customers',
# MAGIC  'incremental','bronze',true,'01_bronze_ingestion',
# MAGIC  NULL,NULL,'max_updated_date',current_date(),current_timestamp(),current_timestamp()),
# MAGIC
# MAGIC -- Orders
# MAGIC ('OBORD001','orders','/Volumes/ecommerce_lakehouse/default/raw/',NULL,
# MAGIC  NULL,'ecommerce_lakehouse.bronze','br_orders',
# MAGIC  'incremental','bronze',true,'01_bronze_ingestion',
# MAGIC  NULL,NULL,'max_updated_date',current_date(),current_timestamp(),current_timestamp()),
# MAGIC
# MAGIC -- Products
# MAGIC ('OBPRD001','products','/Volumes/ecommerce_lakehouse/default/raw/',NULL,
# MAGIC  NULL,'ecommerce_lakehouse.bronze','br_products',
# MAGIC  'incremental','bronze',true,'01_bronze_ingestion',
# MAGIC  NULL,NULL,'max_updated_date',current_date(),current_timestamp(),current_timestamp()),
# MAGIC
# MAGIC -- Order Items
# MAGIC ('OBOIT001','order_items','/Volumes/ecommerce_lakehouse/default/raw/',NULL,
# MAGIC  NULL,'ecommerce_lakehouse.bronze','br_order_items',
# MAGIC  'incremental','bronze',true,'01_bronze_ingestion',
# MAGIC  NULL,NULL,'max_updated_date',current_date(),current_timestamp(),current_timestamp());

# COMMAND ----------

# MAGIC %sql 
# MAGIC Select * from ecommerce_lakehouse.config.metadata where layer='bronze' and isactive = true

# COMMAND ----------

# MAGIC %md
# MAGIC ###Inserting for bronze to silver
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO ecommerce_lakehouse.config.metadata VALUES
# MAGIC
# MAGIC -- ===========================
# MAGIC -- SILVER CUSTOMERS
# MAGIC -- ===========================
# MAGIC ('SLCUS001',
# MAGIC  NULL,
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.bronze.br_customers',
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.silver',
# MAGIC  'sl_customers',
# MAGIC  'incremental',
# MAGIC  'silver',
# MAGIC  true,
# MAGIC  '02_silver_cleaning',
# MAGIC  NULL,
# MAGIC  'customer_id',
# MAGIC  NULL,
# MAGIC  current_timestamp(),
# MAGIC  current_timestamp(),
# MAGIC  NULL
# MAGIC ),
# MAGIC
# MAGIC -- ===========================
# MAGIC -- SILVER ORDERS
# MAGIC -- ===========================
# MAGIC ('SLORD001',
# MAGIC  NULL,
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.bronze.br_orders',
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.silver',
# MAGIC  'sl_orders',
# MAGIC  'incremental',
# MAGIC  'silver',
# MAGIC  true,
# MAGIC  '02_silver_cleaning',
# MAGIC  NULL,
# MAGIC  'order_id',
# MAGIC  NULL,
# MAGIC  current_timestamp(),
# MAGIC  current_timestamp(),
# MAGIC  NULL
# MAGIC ),
# MAGIC
# MAGIC -- ===========================
# MAGIC -- SILVER PRODUCTS
# MAGIC -- ===========================
# MAGIC ('SLPRD001',
# MAGIC  NULL,
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.bronze.br_products',
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.silver',
# MAGIC  'sl_products',
# MAGIC  'incremental',
# MAGIC  'silver',
# MAGIC  true,
# MAGIC  '02_silver_cleaning',
# MAGIC  NULL,
# MAGIC  'product_id',
# MAGIC  NULL,
# MAGIC  current_timestamp(),
# MAGIC  current_timestamp(),
# MAGIC  NULL
# MAGIC ),
# MAGIC
# MAGIC -- ===========================
# MAGIC -- SILVER ORDER ITEMS
# MAGIC -- ===========================
# MAGIC ('SLITM001',
# MAGIC  NULL,
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.bronze.br_order_items',
# MAGIC  NULL,
# MAGIC  'ecommerce_lakehouse.silver',
# MAGIC  'sl_order_items',
# MAGIC  'incremental',
# MAGIC  'silver',
# MAGIC  true,
# MAGIC  '02_silver_cleaning',
# MAGIC  NULL,
# MAGIC  'item_id',
# MAGIC  NULL,
# MAGIC  current_timestamp(),
# MAGIC  current_timestamp(),
# MAGIC  NULL
# MAGIC );

# COMMAND ----------

# MAGIC %sql 
# MAGIC Select * from ecommerce_lakehouse.config.metadata where layer='silver' and isactive = true

# COMMAND ----------

# MAGIC %md
# MAGIC ###Inserting from silver to fact and dim

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO ecommerce_lakehouse.config.metadata (
# MAGIC     meta_id,
# MAGIC     source_table,
# MAGIC     target_path,
# MAGIC     target_table,
# MAGIC     load_type,
# MAGIC     layer,
# MAGIC     isactive,
# MAGIC     notebook_or_pipeline_name,
# MAGIC     primary_key,
# MAGIC     inserted_date,
# MAGIC     updated_date
# MAGIC )
# MAGIC VALUES
# MAGIC
# MAGIC -- DIM CUSTOMERS
# MAGIC (
# MAGIC     'DIMCUS001',
# MAGIC     'ecommerce_lakehouse.silver.sl_customers',
# MAGIC     'ecommerce_lakehouse.silver',
# MAGIC     'dim_customers',
# MAGIC     'incremental',
# MAGIC     'silver',
# MAGIC     true,
# MAGIC     '03_silver_dim_fact',
# MAGIC     'customer_id',
# MAGIC     current_timestamp(),
# MAGIC     current_timestamp()
# MAGIC ),
# MAGIC
# MAGIC -- DIM PRODUCTS
# MAGIC (
# MAGIC     'DIMPRD001',
# MAGIC     'ecommerce_lakehouse.silver.sl_products',
# MAGIC     'ecommerce_lakehouse.silver',
# MAGIC     'dim_products',
# MAGIC     'incremental',
# MAGIC     'silver',
# MAGIC     true,
# MAGIC     '03_silver_dim_fact',
# MAGIC     'product_id',
# MAGIC     current_timestamp(),
# MAGIC     current_timestamp()
# MAGIC ),
# MAGIC
# MAGIC -- FACT ORDERS
# MAGIC (
# MAGIC     'FACTORD001',
# MAGIC     'ecommerce_lakehouse.silver.sl_orders',
# MAGIC     'ecommerce_lakehouse.silver',
# MAGIC     'fact_orders',
# MAGIC     'incremental',
# MAGIC     'silver',
# MAGIC     true,
# MAGIC     '03_silver_dim_fact',
# MAGIC     'order_id',
# MAGIC     current_timestamp(),
# MAGIC     current_timestamp()
# MAGIC ),
# MAGIC
# MAGIC -- FACT ORDER ITEMS
# MAGIC (
# MAGIC     'FACTITM001',
# MAGIC     'ecommerce_lakehouse.silver.sl_order_items',
# MAGIC     'ecommerce_lakehouse.silver',
# MAGIC     'fact_order_items',
# MAGIC     'incremental',
# MAGIC     'silver',
# MAGIC     true,
# MAGIC     '03_silver_dim_fact',
# MAGIC     'item_id',
# MAGIC     current_timestamp(),
# MAGIC     current_timestamp()
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC select * 
# MAGIC FROM ecommerce_lakehouse.config.metadata
# MAGIC WHERE notebook_or_pipeline_name = '03_silver_dim_fact';

# COMMAND ----------

# MAGIC %md
# MAGIC ##Configuring the Audit table

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists ecommerce_lakehouse.config.audit_logging(
# MAGIC     meta_id string,
# MAGIC     run_id string,
# MAGIC     run_date timestamp,
# MAGIC     layer string,
# MAGIC     source_file string,
# MAGIC     target_file string,
# MAGIC     source_table string,
# MAGIC     target_table string,
# MAGIC     start_time timestamp,
# MAGIC     end_time timestamp,
# MAGIC     duration double,
# MAGIC     source_count BIGINT,
# MAGIC     inserted_count BIGINT,
# MAGIC     status string,
# MAGIC     description string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ecommerce_lakehouse.config.audit_logging order by run_date desc

# COMMAND ----------

# MAGIC %md
# MAGIC ##Configuring Schemas

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType

# COMMAND ----------

def bronze_customers_schema():
  return StructType([
    StructField("customer_id",StringType()),
    StructField("first_name",StringType()),
    StructField("last_name",StringType()),
    StructField("email",StringType()),
    StructField("phone",StringType()),
    StructField("city",StringType()),
    StructField("state",StringType()),
    StructField("country",StringType()),
    StructField("registration_date",StringType())
])

# COMMAND ----------

def bronze_order_items_schema():
    return StructType([
        StructField("item_id",StringType()),
        StructField("order_id",StringType()),
        StructField("product_id",StringType()),
        StructField("quantity",StringType()),
        StructField("unit_price",StringType()),
        StructField("discount_pct",StringType()),
        StructField("line_total",StringType())
    ])

# COMMAND ----------

def bronze_orders_schema():
    return StructType([
        StructField("order_id",StringType()),
        StructField("customer_id",StringType()),
        StructField("order_date",StringType()),
        StructField("order_status",StringType()),
        StructField("total_amount",StringType()),
        StructField("payment_method",StringType()),
        StructField("shipping_address",StringType()),
        StructField("created_at",StringType())
    ])

# COMMAND ----------

def bronze_products_schema():
    return StructType([
        StructField("product_id",StringType()),
        StructField("product_name",StringType()),
        StructField("category",StringType()),
        StructField("sub_category",StringType()),
        StructField("unit_price",StringType()),
        StructField("cost_price",StringType()),
        StructField("supplier",StringType()),
        StructField("stock_quantity",StringType()),
        StructField("is_active",StringType()),
        StructField("created_date",StringType())
    ])

# COMMAND ----------

# MAGIC %md
# MAGIC ##Enabling CDF on bronze

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE ecommerce_lakehouse.bronze.br_customers
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.bronze.br_orders
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.bronze.br_products
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.bronze.br_order_items
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ###Checking and enabling CDF on silver

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TBLPROPERTIES ecommerce_lakehouse.silver.sl_orders;

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE ecommerce_lakehouse.silver.sl_customers
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.silver.sl_orders
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.silver.sl_products
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC ALTER TABLE ecommerce_lakehouse.silver.sl_order_items
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

# COMMAND ----------

# MAGIC %md
# MAGIC ###Extending metadata table for fact and dim supported

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE ecommerce_lakehouse.config.metadata
# MAGIC ADD COLUMNS (
# MAGIC     table_type STRING,           -- DIM / FACT
# MAGIC     surrogate_key STRING,
# MAGIC     is_scd STRING,               -- SCD1 / SCD2
# MAGIC     scd_tracking_column STRING
# MAGIC );

# COMMAND ----------

