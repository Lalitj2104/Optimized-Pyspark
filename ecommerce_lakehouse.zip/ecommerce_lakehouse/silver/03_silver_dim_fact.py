# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.types import *
from delta.tables import DeltaTable
from datetime import datetime
import uuid

CATALOG = "ecommerce_lakehouse"
spark.sql(f"USE CATALOG {CATALOG}")

METADATA_TABLE = f"{CATALOG}.config.metadata"
AUDIT_TABLE = f"{CATALOG}.config.audit_logging"
WATERMARK_TABLE = f"{CATALOG}.silver.dimfact_watermarks"

RUN_ID = str(uuid.uuid4())[:8]

print(f"Dim/Fact CDF processing started | Run ID: {RUN_ID}")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS ecommerce_lakehouse.silver.dimfact_watermarks (
# MAGIC     meta_id STRING,
# MAGIC     source_table STRING,
# MAGIC     target_table STRING,
# MAGIC     last_processed_version BIGINT,
# MAGIC     updated_at TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

audit_schema = StructType([
    StructField("meta_id", StringType(), True),
    StructField("run_id", StringType(), True),
    StructField("run_date", TimestampType(), True),
    StructField("layer", StringType(), True),
    StructField("source_file", StringType(), True),
    StructField("target_file", StringType(), True),
    StructField("source_table", StringType(), True),
    StructField("target_table", StringType(), True),
    StructField("start_time", TimestampType(), True),
    StructField("end_time", TimestampType(), True),
    StructField("duration", DoubleType(), True),
    StructField("source_count", LongType(), True),
    StructField("inserted_count", LongType(), True),
    StructField("status", StringType(), True),
    StructField("description", StringType(), True)
])

def log_audit(meta_id, source_table, target_table,
              start_time, end_time,
              source_count, inserted_count,
              status, description):

    duration = (end_time - start_time).total_seconds()

    data = [(
        meta_id,
        RUN_ID,
        datetime.now(),
        "silver",
        None,
        None,
        source_table,
        target_table,
        start_time,
        end_time,
        duration,
        int(source_count),
        int(inserted_count),
        status,
        description
    )]

    spark.createDataFrame(data, audit_schema) \
        .write.mode("append") \
        .saveAsTable(AUDIT_TABLE)

# COMMAND ----------

metadata_df = spark.table(METADATA_TABLE).filter("""
    layer = 'silver'
    AND isactive = true
    AND notebook_or_pipeline_name = '03_silver_dim_fact'
""")

configs = metadata_df.collect()

# COMMAND ----------

for row in configs:

    meta_id = row.meta_id
    source_table = row.source_table
    target_table = f"{row.target_path}.{row.target_table}"
    pk = row.primary_key

    print(f"\nProcessing: {target_table}")

    start_time = datetime.now()

    try:

        # Get last processed version
        wm = spark.table(WATERMARK_TABLE) \
                  .filter(F.col("meta_id") == meta_id) \
                  .first()

        if wm is None:
            print("Cold start → Full load from Silver")
            df = spark.table(source_table)
        else:
            print(f"CDF from version {wm.last_processed_version + 1}")

            df = (spark.read.format("delta")
                  .option("readChangeFeed", "true")
                  .option("startingVersion", wm.last_processed_version + 1)
                  .table(source_table)
                  .filter(F.col("_change_type")
                          .isin("insert","update_postimage")))

        if df.limit(1).count() == 0:
            print("No new changes.")
            continue

        source_count = df.count()

        # SCD Type 1 for dimensions
        if "dim_" in target_table:

            if not spark.catalog.tableExists(target_table):
                df.write.format("delta") \
                    .mode("overwrite") \
                    .saveAsTable(target_table)
            else:
                (DeltaTable.forName(spark,target_table)
                 .alias("t")
                 .merge(df.alias("s"),
                        f"t.{pk} = s.{pk}")
                 .whenMatchedUpdateAll()
                 .whenNotMatchedInsertAll()
                 .execute())

        # FACT tables
        elif "fact_" in target_table:

            if not spark.catalog.tableExists(target_table):
                df.write.format("delta") \
                    .mode("overwrite") \
                    .saveAsTable(target_table)
            else:
                (DeltaTable.forName(spark,target_table)
                 .alias("t")
                 .merge(df.alias("s"),
                        f"t.{pk} = s.{pk}")
                 .whenMatchedUpdateAll()
                 .whenNotMatchedInsertAll()
                 .execute())

        inserted_count = df.count()

        # Update watermark
        latest_version = (
            spark.sql(f"DESCRIBE HISTORY {source_table}")
                 .selectExpr("max(version) as max_version")
                 .first()[0]
        )

        spark.sql(f"""
        MERGE INTO {WATERMARK_TABLE} t
        USING (
            SELECT
                '{meta_id}' as meta_id,
                '{source_table}' as source_table,
                '{target_table}' as target_table,
                {latest_version} as last_processed_version,
                current_timestamp() as updated_at
        ) s
        ON t.meta_id = s.meta_id
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
        """)

        end_time = datetime.now()

        log_audit(meta_id,
                  source_table,
                  target_table,
                  start_time,
                  end_time,
                  source_count,
                  inserted_count,
                  "SUCCESS",
                  "Incremental CDF load")

    except Exception as e:

        end_time = datetime.now()

        log_audit(meta_id,
                  source_table,
                  target_table,
                  start_time,
                  end_time,
                  0,
                  0,
                  "FAILED",
                  str(e))

        raise

# COMMAND ----------

spark.sql('''select * from ecommerce_lakehouse.silver.fact_order_items ''').display()

# COMMAND ----------

