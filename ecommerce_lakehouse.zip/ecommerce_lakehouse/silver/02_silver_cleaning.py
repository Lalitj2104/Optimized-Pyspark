# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from delta.tables import DeltaTable
from datetime import datetime
import uuid

CATALOG = "ecommerce_lakehouse"

spark.sql(f"USE CATALOG {CATALOG}")

BATCH_ID = str(uuid.uuid4())

METADATA_TABLE = f"{CATALOG}.config.metadata"
AUDIT_TABLE = f"{CATALOG}.config.audit_logging"
WATERMARK_TABLE = f"{CATALOG}.silver.cdf_watermarks"

print(f"Batch ID = {BATCH_ID}")

# COMMAND ----------

audit_schema = StructType([
    StructField("meta_id", StringType(), True),
    StructField("run_id", StringType(), True),
    StructField("run_date", TimestampType(), True),
    StructField("layer", StringType(), True),
    StructField("source_file", StringType(), True),
    StructField("target_file", StringType(), True),
    StructField("source_table", StringType(), True),
    StructField("target_table", StringType(), True),
    StructField("start_time", TimestampType(), True),
    StructField("end_time", TimestampType(), True),
    StructField("duration", DoubleType(), True),
    StructField("source_count", LongType(), True),
    StructField("inserted_count", LongType(), True),
    StructField("status", StringType(), True),
    StructField("description", StringType(), True)
])

def log_audit(meta_id, source_table, target_table,
              start_time, end_time,
              source_count, inserted_count,
              status, description):

    duration = (end_time - start_time).total_seconds()

    data = [(
        meta_id,
        BATCH_ID,
        datetime.now(),
        "silver",
        None,
        None,
        source_table,
        target_table,
        start_time,
        end_time,
        duration,
        int(source_count),
        int(inserted_count),
        status,
        description
    )]

    spark.createDataFrame(data, audit_schema) \
        .write.mode("append") \
        .saveAsTable(AUDIT_TABLE)

# COMMAND ----------

def deduplicate(df, key_col):
    w = Window.partitionBy(key_col).orderBy(F.col("ingestion_time").desc())
    return (df.withColumn("rn", F.row_number().over(w))
              .filter(F.col("rn") == 1)
              .drop("rn"))

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {WATERMARK_TABLE} (
    meta_id STRING,
    last_processed_version LONG,
    updated_at TIMESTAMP
)
""")

def get_watermark(meta_id):
    try:
        row = (spark.table(WATERMARK_TABLE)
               .filter(F.col("meta_id") == meta_id)
               .first())
        return row.last_processed_version if row else None
    except:
        return None

def update_watermark(meta_id, bronze_table):
    version = (spark.sql(f"DESCRIBE HISTORY {bronze_table}")
               .selectExpr("max(version) as v")
               .first()["v"])

    spark.sql(f"""
    MERGE INTO {WATERMARK_TABLE} t
    USING (SELECT '{meta_id}' as meta_id,
                  {version} as last_processed_version,
                  current_timestamp() as updated_at) s
    ON t.meta_id = s.meta_id
    WHEN MATCHED THEN UPDATE SET *
    WHEN NOT MATCHED THEN INSERT *
    """)

# COMMAND ----------

metadata_df = spark.table(METADATA_TABLE).filter("""
    layer = 'silver'
    AND isactive = true
    AND notebook_or_pipeline_name = '02_silver_cleaning'
""")

configs = metadata_df.collect()

# COMMAND ----------

for row in configs:

    meta_id      = row.meta_id
    bronze_table = row.source_table
    silver_table = f"{row.target_path}.{row.target_table}"
    pk           = row.primary_key

    print(f"\nProcessing: {silver_table}")

    start_time = datetime.now()

    try:

        last_version = get_watermark(meta_id)

        if last_version is None:
            df = spark.table(bronze_table)
        else:
            df = (spark.read.format("delta")
                  .option("readChangeFeed","true")
                  .option("startingVersion", last_version + 1)
                  .table(bronze_table)
                  .filter(F.col("_change_type").isin("insert","update_postimage")))

        if df.limit(1).count() == 0:
            print("  No new records.")
            continue

        source_count = df.count()

        df = deduplicate(df, pk)

        # ==========================
        # TABLE-SPECIFIC CLEANING
        # ==========================

        if "customers" in silver_table:

            df = (df
                .withColumn("email", F.lower(F.trim(F.col("email"))))
                .withColumn("registration_date",
                            F.to_date("registration_date","yyyy-MM-dd"))
            )

        if "orders" in silver_table:
            df = df.withColumn("order_status",
                               F.upper(F.trim(F.col("order_status"))))

        if "products" in silver_table:
            df = df.withColumn("product_name",
                               F.initcap(F.col("product_name")))

        if "order_items" in silver_table:
            df = df.withColumn("discount_pct",
                               F.coalesce(F.col("discount_pct"), F.lit(0.0)))

        # Add silver metadata
        df = df.withColumn("_silver_loaded_at", F.current_timestamp()) \
               .drop("_source_file","_batch_id")

        # MERGE
        if not spark.catalog.tableExists(silver_table):
            df.write.format("delta").mode("overwrite").saveAsTable(silver_table)
        else:
            (DeltaTable.forName(spark, silver_table).alias("t")
             .merge(df.alias("s"), f"t.{pk} = s.{pk}")
             .whenMatchedUpdateAll()
             .whenNotMatchedInsertAll()
             .execute())

        inserted = df.count()

        update_watermark(meta_id, bronze_table)

        end_time = datetime.now()

        log_audit(meta_id,
                  bronze_table,
                  silver_table,
                  start_time,
                  end_time,
                  source_count,
                  inserted,
                  "SUCCESS",
                  "Completed")

        print(f"  {silver_table} processed successfully.")

    except Exception as e:

        end_time = datetime.now()

        log_audit(meta_id,
                  bronze_table,
                  silver_table,
                  start_time,
                  end_time,
                  0,
                  0,
                  "FAILED",
                  str(e))

        raise

# COMMAND ----------

